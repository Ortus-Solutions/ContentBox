﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'th', {
	btnIgnore: 'ยกเว้น',
	btnIgnoreAll: 'ยกเว้นทั้งหมด',
	btnReplace: 'แทนที่',
	btnReplaceAll: 'แทนที่ทั้งหมด',
	btnUndo: 'ยกเลิก',
	changeTo: 'แก้ไขเป็น',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'ไม่ได้ติดตั้งระบบตรวจสอบคำสะกด. ต้องการติดตั้งไหมครับ?',
	manyChanges: 'ตรวจสอบคำสะกดเสร็จสิ้น:: แก้ไข %1 คำ',
	noChanges: 'ตรวจสอบคำสะกดเสร็จสิ้น: ไม่มีการแก้คำใดๆ',
	noMispell: 'ตรวจสอบคำสะกดเสร็จสิ้น: ไม่พบคำสะกดผิด',
	noSuggestions: '- ไม่มีคำแนะนำใดๆ -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'ไม่พบในดิกชันนารี',
	oneChange: 'ตรวจสอบคำสะกดเสร็จสิ้น: แก้ไข1คำ',
	progress: 'กำลังตรวจสอบคำสะกด...',
	title: 'Spell Check',
	toolbar: 'ตรวจการสะกดคำ'
});
