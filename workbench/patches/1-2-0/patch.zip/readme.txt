﻿********************************************************************************
ContentBox Modular CMS - A Modular Content Platform
Copyright 2012 by Luis Majano and Ortus Solutions, Corp
www.gocontentbox.org | www.luismajano.com | www.ortussolutions.com
********************************************************************************
HONOR GOES TO GOD ABOVE ALL
********************************************************************************
Because of His grace, this project exists. If you don't like this, then don't read it, its not for you.

"Therefore being justified by faith, we have peace with God through our Lord Jesus Christ:
By whom also we have access by faith into this grace wherein we stand, and rejoice in hope of the glory of God.
And not only so, but we glory in tribulations also: knowing that tribulation worketh patience;
And patience, experience; and experience, hope:
And hope maketh not ashamed; because the love of God is shed abroad in our hearts by the 
Holy Ghost which is given unto us. ." Romans 5:5

********************************************************************************
WELCOME TO CONTENTBOX
********************************************************************************
A Modular Content Platform!
Created & copyright by Luis Majano (Ortus Solutions, Corp - www.ortussolutions.com)
Powered by ColdBox (www.coldbox.org)

********************************************************************************
VERSIONING
********************************************************************************
ContentBox is maintained under the Semantic Versioning guidelines as much as possible.

Releases will be numbered with the following format:

<major>.<minor>.<patch>

And constructed with the following guidelines:

* Breaking backward compatibility bumps the major (and resets the minor and patch)
* New additions without breaking backward compatibility bumps the minor (and resets the patch)
* Bug fixes and misc changes bumps the patch

********************************************************************************
CONTENTBOX LICENSE
********************************************************************************
ContentBox and ColdBox are open source and bound to the Apache License, Version 2.0. If you use ContentBox, 
please try to make mention of it in your code or web site or add a Powered By ContentBox icon.  
Please donate, this project lives thanks to your donations and professional open source services.

The ColdBox, ContentBox Websites, logo and content have a separate license and they are a separate entity.

********************************************************************************
OPEN SOURCE INITIATIVE APPROVED
********************************************************************************
This software is Open Source Initiative approved Open Source Software.
Open Source Initiative Approved is a trademark of the Open Source Initiative.

********************************************************************************
CREDITS & CONTRIBUTIONS
********************************************************************************
I have included some software from other open source projects and I have used
some code from open source projects in this application. If I have forgotten
to name someone, please send me an email about it.

GOD	
	I THANK GOD FOR HIS WISDOM FOR THIS PROJECT

- Curt Gratz
- Computer Know How Team
- Mike McKellip
- James Spoonmore
- Brad Wood
- Tim Cunningham
- Aaron Greenlee
- Sana Ullah
- Josh Giese
- Kalen Gibbons
- Veronica Monedero & Alexia Majano (Thanks babes!)

********************************************************************************
CONTENTBOX IMPORTANT LINKS
********************************************************************************
Source Code
- https://github.com/Ortus-Solutions/ContentBox
Tracker Site (Bug Tracking, Issues)
- http://coldbox.assembla.com/spaces/contentbox
Documentation
- http://www.gocontentbox.org
Blog
- http://www.gocontentbox.org/blog

********************************************************************************
CONTENTBOX INSTALLATION
********************************************************************************
1) Download (You already did this)
2) Extract to a folder named anything besides ContentBox (cb, blog, mycms etc.)
3) Create a database in your favorite database engine
4) Create a datasource in your ColdFusion administrator called 'contentbox'
5) Go to this site http://localhost and follow the installer.

********************************************************************************
SYSTEM REQUIREMENTS
********************************************************************************
- Adobe ColdFusion 9.0.1 >
- Railo Latest
- Session Scope Enabled


AS ALWAYS, VISIT THE SITE FOR THE LATEST DOCUMENTATION

******************************************************************************** 
THE DAILY BREAD
********************************************************************************

 "I am the way, and the truth, and the life; no one comes to the Father, but by me (JESUS)" Jn 14:1-12